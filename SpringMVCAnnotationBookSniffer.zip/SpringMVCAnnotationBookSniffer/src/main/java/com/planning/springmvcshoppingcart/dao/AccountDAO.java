package com.planning.springmvcshoppingcart.dao;
import com.planning.springmvcshoppingcart.entity.Account;

public interface AccountDAO {
 
    
    public Account findAccount(String userName );
    
}